
const express = require("express");
const router = express.Router();

const recetaController = require("../controllers/recetaController");

// Consultar todas las recetas.
router.get("/", recetaController.listar);

// Consultar los ingredientes de un producto específico.
router.get("/producto/:productoId", recetaController.obtenerPorProducto);

module.exports = router;
