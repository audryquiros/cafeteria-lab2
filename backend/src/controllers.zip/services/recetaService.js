
const db = require("../db");

function listarRecetas() {
  return db.prepare(`
    SELECT
      r.id,
      p.id AS producto_id,
      p.nombre AS producto,
      p.activo,
      i.id AS insumo_id,
      i.nombre AS insumo,
      r.cantidad,
      i.unidad,
      i.stock AS stock_disponible
    FROM recetas r
    INNER JOIN productos p ON p.id = r.producto_id
    INNER JOIN insumos i ON i.id = r.insumo_id
    ORDER BY p.nombre ASC, i.nombre ASC
  `).all();
}

function obtenerRecetaPorProducto(productoId) {
  return db.prepare(`
    SELECT
      p.id AS producto_id,
      p.nombre AS producto,
      p.activo,
      i.id AS insumo_id,
      i.nombre AS insumo,
      r.cantidad,
      i.unidad,
      i.stock AS stock_disponible
    FROM recetas r
    INNER JOIN productos p ON p.id = r.producto_id
    INNER JOIN insumos i ON i.id = r.insumo_id
    WHERE p.id = ?
    ORDER BY i.nombre ASC
  `).all(productoId);
}

module.exports = {
  listarRecetas,
  obtenerRecetaPorProducto
};
