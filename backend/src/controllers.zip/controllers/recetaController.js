
const recetaService = require("../services/recetaService");

function listar(req, res) {
  try {
    const recetas = recetaService.listarRecetas();

    const productos = {};

    for (const receta of recetas) {
      if (!productos[receta.producto_id]) {
        productos[receta.producto_id] = {
          producto_id: receta.producto_id,
          producto: receta.producto,
          activo: receta.activo,
          disponible: Boolean(receta.activo),
          insumos: []
        };
      }

      productos[receta.producto_id].insumos.push({
        insumo_id: receta.insumo_id,
        insumo: receta.insumo,
        cantidad_necesaria: receta.cantidad,
        unidad: receta.unidad,
        stock_disponible: receta.stock_disponible
      });

      if (receta.stock_disponible < receta.cantidad) {
        productos[receta.producto_id].disponible = false;
      }
    }

    res.status(200).json(Object.values(productos));
  } catch (error) {
    console.error("Error al listar recetas:", error);
    res.status(500).json({ error: "Error interno al consultar las recetas" });
  }
}

function obtenerPorProducto(req, res) {
  const productoId = Number(req.params.productoId);

  if (!Number.isInteger(productoId) || productoId <= 0) {
    return res.status(400).json({ error: "El ID del producto debe ser un entero positivo" });
  }

  try {
    const recetas = recetaService.obtenerRecetaPorProducto(productoId);

    if (recetas.length === 0) {
      return res.status(404).json({
        error: "No se encontró una receta para ese producto"
      });
    }

    const disponible = Boolean(recetas[0].activo) &&
      recetas.every((receta) => receta.stock_disponible >= receta.cantidad);

    res.status(200).json({
      producto_id: recetas[0].producto_id,
      producto: recetas[0].producto,
      disponible,
      insumos: recetas.map((receta) => ({
        insumo_id: receta.insumo_id,
        insumo: receta.insumo,
        cantidad_necesaria: receta.cantidad,
        unidad: receta.unidad,
        stock_disponible: receta.stock_disponible
      }))
    });
  } catch (error) {
    console.error("Error al consultar receta:", error);
    res.status(500).json({ error: "Error interno al consultar la receta" });
  }
}

module.exports = {
  listar,
  obtenerPorProducto
};
